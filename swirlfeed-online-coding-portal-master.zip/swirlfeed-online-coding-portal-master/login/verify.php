<?php
$email=$_REQUEST['email1'];

?>
